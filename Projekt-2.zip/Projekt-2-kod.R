library(dplyr)
library(ggplot2)
library(questionr)

rm(list=ls())
dane <- read.csv("term_deposit_prediction_data_set.csv", header =  TRUE, 
                 sep = ",", dec = ".")

head(dane)
str(dane)


# Braki w danych:
braki_dane <- colSums(is.na(dane))
# W zbiorze nie ma braków w danych.

#-------------------------------------------------------------------------------
# ---------------------------DOSTOSOWANIE DANYCH--------------------------------
#-------------------------------------------------------------------------------

# Na początku ze zbioru zostanie wykluczona zmienna „ID” oraz 
# „pdays” - jest to ilość dni jaka upłynęła od ostatniego kontaktu z klientem. 
# Dla tej zmiennej wartości nie są dokładnie opisane.

dane <- dane %>%
  select(-ID, -pdays)

# Dane są złożone ze zmiennych ilosciowych i ze zmiennych kategorycznych. 
#Zmienne kategoryczne zostaną odpowiednio zakodowane (binarnie).

#---------------------------------ZMIENNE ILOSCIOWE--------------------------------

# Podstawowe statystyki dla zmiennych ciągłych
dane_ciagle <- dane %>%
  select(age, balance, duration, campaign, previous)

summary(dane_ciagle)
sd(dane_ciagle[,1])

dane.dostosowane <- dane_ciagle

#------------------------MAPOWANIE DANYCH KATEGORYCZNYCH----------------------

# Zakodowanie zmiennej "job"
# blue-collar - pracownik fizyczny
# management - kadra zarządzajaca
# technician - pracownik techniczny
# admin. - pracownik administracyjny
# services - pracownik sektora usługowego
# retired  - emeryt
# housemaid - pomoc domowa
# self-employed - samozatrudniony
# student - student
# entrepreneur - przedsiębiorca 
# unemployed  - bezrobotny
# unknown - nieznany

job <- dane %>%
  distinct(job)


dane.dostosowane$job_blue_collar <- 0
dane.dostosowane$job_management <- 0
dane.dostosowane$job_technician <- 0
dane.dostosowane$job_admin <- 0
dane.dostosowane$job_services <- 0
dane.dostosowane$job_retired <- 0
dane.dostosowane$job_housemaid <- 0
dane.dostosowane$job_entrepreneur <- 0
dane.dostosowane$job_unemployed <- 0
dane.dostosowane$job_unknown <- 0


for (i in 1:dim(dane)[1]){
  if(dane$job[i] == "blue-collar"){
    dane.dostosowane$job_blue_collar[i] <- 1
  }
  if(dane$job[i] == "management"){
    dane.dostosowane$job_management[i] <- 1
  }
  if(dane$job[i] == "technician"){
    dane.dostosowane$job_technician[i] <- 1
  }
  if(dane$job[i] == "admin."){
    dane.dostosowane$job_admin[i] <- 1
  }
  if(dane$job[i] == "services"){
    dane.dostosowane$job_services[i] <- 1
  }
  if(dane$job[i] == "retired"){
    dane.dostosowane$job_retired[i] <- 1
  }
  if(dane$job[i] == "housemaid"){
    dane.dostosowane$job_housemaid[i] <- 1
  }
  if(dane$job[i] == "entrepreneur"){
    dane.dostosowane$job_entrepreneur[i] <- 1
  }
  if(dane$job[i] == "unemployed"){
    dane.dostosowane$job_unemployed[i] <- 1
  }
  if(dane$job[i] == "unknown"){
    dane.dostosowane$job_unknown[i] <- 1
  }
}


# Zakodowanie zmiennej "marital"
# married - zaślubiony
# divorced - rozwiedziony
# single - singiel 

marital <- dane %>%
  distinct(marital)

dane.dostosowane$marital_married <- 0
dane.dostosowane$marital_divorced <- 0
dane.dostosowane$marital_single <- 0

for (i in 1:dim(dane)[1]){
  if(dane$marital[i] == "married"){
    dane.dostosowane$marital_married[i] <- 1
  }
  if(dane$marital[i] == "divorced"){
    dane.dostosowane$marital_divorced[i] <- 1
  }
  if(dane$marital[i] == "single"){
    dane.dostosowane$marital_single[i] <- 1
  }
}


# Zakodowanie zmiennej "education"
# unknow - nieznane
# secondary - Średnie 
# tertiary - wyższe
# primary - podstawowe

education <- dane %>%
  distinct(education)

dane.dostosowane$education_unknow <- 0
dane.dostosowane$education_secondary <- 0
dane.dostosowane$education_tertiary  <- 0
dane.dostosowane$education_primary <- 0

for (i in 1:dim(dane)[1]){
  if(dane$education[i] == "unknow"){
    dane.dostosowane$education_unknow[i] <- 1
  }
  if(dane$education[i] == "secondary"){
    dane.dostosowane$education_secondary[i] <- 1
  }
  if(dane$education[i] == "tertiary"){
    dane.dostosowane$education_tertiary[i] <- 1
  }
  if(dane$education[i] == "primary"){
    dane.dostosowane$education_primary[i] <- 1
  }
}


# Zakodowanie zmiennej "default"
# Zmienna „default” (yes/no) odpowiada za oznaczenie czy ktoś zalega ze 
# spłatą karty kredytowej dłużej niż miesiąc, a krócej niż poł roku. 

default <- dane %>%
  distinct(default)

dane.dostosowane$default <- 0

for (i in 1:dim(dane)[1]){
  if(dane$default[i] == "yes"){
    dane.dostosowane$default[i] <- 1
  }
}


# Zakodowanie zmiennej "housing"
# Zmienna housing (yes/no) odpowiada za oznaczenie, 
# czy dany klient ma kredyt mieszkaniowy. 

housing <- dane %>%
  distinct(housing)

dane.dostosowane$housing <- 0

for (i in 1:dim(dane)[1]){
  if(dane$housing[i] == "yes"){
    dane.dostosowane$housing[i] <- 1
  }
}


# Zakodowanie zmiennej "loan"
# Zmienna loan (yes/no) odpowiada za oznaczenie, 
# czy dany klient ma pożyczkę osobistą.

loan <- dane %>%
  distinct(loan)

dane.dostosowane$loan <- 0

for (i in 1:dim(dane)[1]){
  if(dane$loan[i] == "yes"){
    dane.dostosowane$loan[i] <- 1
  }
}


# Zakodowanie zmiennej "contact"
# telephone - tel stacjonarny
# cellular - komórka
# unknown - nieznany

contact <- dane %>%
  distinct(contact)

dane.dostosowane$contact_telephone <- 0
dane.dostosowane$contact_cellular  <- 0
dane.dostosowane$contact_unknown <- 0


for (i in 1:dim(dane)[1]){
  if(dane$contact[i] == "unknow"){
    dane.dostosowane$contact_unknow[i] <- 1
  }
  if(dane$contact[i] == "telephone"){
    dane.dostosowane$contact_telephone[i] <- 1
  }
  if(dane$contact[i] == "cellular"){
    dane.dostosowane$contact_cellular [i] <- 1
  }
}

# Zakodowanie zmiennej "month"
month <- dane %>%
  distinct(month)

dane.dostosowane$month <- 0

for (i in 1:dim(dane)[1]){
  if(dane$month[i] == "jan"){
    dane.dostosowane$month[i] <- 1
  }
  if(dane$month[i] == "feb"){
    dane.dostosowane$month[i] <- 2
  }
  if(dane$month[i] == "mar"){
    dane.dostosowane$month[i] <- 3
  }
  if(dane$month[i] == "apr"){
    dane.dostosowane$month[i] <- 4
  }
  if(dane$month[i] == "may"){
    dane.dostosowane$month[i] <- 5
  }
  if(dane$month[i] == "jun"){
    dane.dostosowane$month[i] <- 6
  }
  if(dane$month[i] == "jul"){
    dane.dostosowane$month[i] <- 7
  }
  if(dane$month[i] == "aug"){
    dane.dostosowane$month[i] <- 8
  }
  if(dane$month[i] == "sep"){
    dane.dostosowane$month[i] <- 9
  }
  if(dane$month[i] == "oct"){
    dane.dostosowane$month[i] <- 10
  }
  if(dane$month[i] == "nov"){
    dane.dostosowane$month[i] <- 11
  }
  if(dane$month[i] == "dec"){
    dane.dostosowane$month [i] <- 12
  }
  
}

# Zakodowanie zmiennej "day"
# !!!!! UWAGA !!!!
# Zamienię dzień tygodnia na zmienna jakościową 1-4, żeby mieć tylko informację 
# w którym tygodniu miesiąca przedstawiciel banku kontaktował się z klientem.

dane.dostosowane$week <- NA

for(i in 1:dim(dane)[1]){
  if(dane$day[i] < 8){
    dane.dostosowane$week[i] <- 1
  }
  if(dane$day[i] >= 8 && dane$day[i] < 16){
    dane.dostosowane$week[i] <- 2
  }
  if(dane$day[i] >= 16 && dane$day[i] < 22){
    dane.dostosowane$week[i] <- 3
  }
  if(dane$day[i] >= 22){
    dane.dostosowane$week[i] <- 4
  }
}

# Zakodowanie zmiennej "poutcome" - wyniki z poprzedniej kampanii
# unknow - nieznane
# success - sukces
# failure - porażka
# other - inne

poutcome <- dane %>%
  distinct(poutcome)

dane.dostosowane$poutcome_unknown <- 0
dane.dostosowane$poutcome_success <- 0
dane.dostosowane$poutcome_failure <- 0
dane.dostosowane$poutcome_other <- 0

for (i in 1:dim(dane)[1]){
  if(dane$poutcome[i] == "unknown"){
    dane.dostosowane$poutcome_unknown[i] <- 1
  }
  if(dane$poutcome[i] == "success"){
    dane.dostosowane$poutcome_success[i] <- 1
  }
  if(dane$poutcome[i] == "failure"){
    dane.dostosowane$poutcome_failure[i] <- 1
  }
  if(dane$poutcome[i] == "other"){
    dane.dostosowane$poutcome_other[i] <- 1
  }
}

# Zakodowanie zmiennej "subscribed" (yes/no) - zmienna Y

subscribed <- dane %>%
  distinct(subscribed)

dane.dostosowane$subscribed <- 0

for (i in 1:dim(dane)[1]){
  if(dane$subscribed[i] == "yes"){
    dane.dostosowane$subscribed[i] <- 1
  }
}

#-------Analiza wpływu poszczególnych zmiennych na zmienna prognozowaną Y-------

dane_Y <- dane.dostosowane %>%
  dplyr::filter(subscribed == 1)


# Wykres dla zmiennej subscribed – wartość zmiennej prognozwoanej
subscribed_wykres <- dane %>%
  ggplot(aes(factor(subscribed), fill = factor(subscribed))) +
  geom_bar() + 
  labs(x= "Subscribed",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 25000, 5000))+
  ggtitle("Wyniki kampanii marketingowej")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))
# Ile procent klientów zdecydowało się nie wpłacenie pieniędzy na lokatę
sum(dane$subscribed == "yes")/nrow(dane) *100



# Wykres dla zmiennej "job"
job_wykres <- dane %>%
  ggplot(aes(factor(job), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Job type",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 6000, 1000))+
  ggtitle("Wyniki kampanii marketingowej w zależności od sektora zatrudnienia")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        axis.text.x = element_text(angle=90, hjust=1))

  
sum(dane_Y$job_technician,
    dane_Y$job_management,
    dane_Y$job_technician,
    dane_Y$job_retired,
    dane_Y$job_admin)/nrow(dane_Y)*100



# Wykres dla zmiennej "marital"
marital_wykres <- dane %>%
  ggplot(aes(factor(marital), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Marital",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 15000, 5000))+
  ggtitle("Wyniki kampanii marketingowej w zależności od stanu cywilnego")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))

sum(dane_Y$marital_single)/nrow(dane_Y)*100



# Wykres dla zmiennej "education"
education_wykres <- dane %>%
  ggplot(aes(factor(education), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Education",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 15000, 5000))+
  ggtitle("Wyniki kampanii marketingowej w zależności od wykształcenia")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))

sum(dane_Y$education_tertiary)/nrow(dane_Y)*100


# Wykres dla zmiennej "default"
default_wykres <- dane %>%
  ggplot(aes(factor(default), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Default",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 27500, 2500))+
  ggtitle("Wyniki kampanii marketingowej w zależności od tego czy klient zalega ze spłatami karty kredytowej")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))

(dane_Y$default == 0)/nrow(dane_Y)*100


# Wykres dla zmiennej "housing"
housing_wykres <- dane %>%
  ggplot(aes(factor(housing), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Housing",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 15000, 2500))+
  ggtitle("Wyniki kampanii marketingowej w zależności od tego czy klient zaciągnął kredyt mieszkaniowy")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))

sum(dane_Y$housing == 0)/nrow(dane_Y)*100


# Wykres dla zmiennej "loan"
loan_wykres <- dane %>%
  ggplot(aes(factor(loan), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Loan",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 22500, 2500))+
  ggtitle("Wyniki kampanii marketingowej w zależności od tego czy klient zaciągnął kredyt osobisty")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))

sum(dane_Y$loan == 0)/nrow(dane_Y)*100

# Wykres dla zmiennej "contact"
contact_wykres <- dane %>%
  ggplot(aes(factor(contact), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Contact",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 22500, 2500))+
  ggtitle("Wyniki kampanii marketingowej w zależności sposobu kontaktu z klientem")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))

sum(dane_Y$contact_cellular == 1)/nrow(dane_Y)*100

# Wykres dla zmiennej "poucome"
poutcome_wykres <- dane %>%
  ggplot(aes(factor(poutcome), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Poutcome",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 25000, 5000))+
  ggtitle("Wyniki kampanii marketingowej w zależności od wyników poprzednich kampanii")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))

sum(dane_Y$poutcome_unknow == 1)/nrow(dane_Y)*100

# Wykres dla zmiennej "month"
# Korzystam z dane.dostosowane ponieważ są już zamienione na odpowiedni format 
# użyty w dalszej części badania.
month_wykres <- dane.dostosowane %>%
  ggplot(aes(factor(month), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Month",
       y = "Count",
       fill = "Subscribed")+
  scale_x_discrete(labels = c("jan", "feb", "mar",
                             "apr", "may", "jun",
                             "jul","aug","sep",
                             "oct","nov","dec"))+
  scale_y_continuous(breaks = seq(0, 8000, 2000))+
  ggtitle("Wyniki kampanii marketingowej w zależności od miesiąca kontaktu z klientem")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5)) 
  


# Wykres dla zmiennej "day"
# Korzystam z dane.dostosowane ponieważ są już zamienione na odpowiedni format 
# użyty w dalszej części badania.
day_wykres <- dane.dostosowane %>%
  ggplot(aes(factor(week), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Week",
       fill = "Subscribed",
       y = "Count")+
  scale_y_continuous(breaks = seq(0, 8000, 2000))+
  ggtitle("Wyniki kampanii marketingowej w zależności od tygodnia kontaktu z klientem")+
  theme_minimal()+
theme(legend.position = "right",
      axis.text = element_text(size = 15),
      axis.title = element_text(size = 18),
      legend.text = element_text(size = 15),
      legend.title = element_text(size = 18),
      plot.title = element_text(size = 18, face = "bold", hjust = 0.5)) 

sum(dane_Y$week == 4)/nrow(dane_Y)*100


# Wykres dla zmiennej "age"
age_wykres  <- ggplot(dane) +
  geom_boxplot(aes(y = age, fill=subscribed)) + 
  labs(fill=  "Subscribed",
       y = "Age")+
  ggtitle("Wiek klientów")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5)) 

dane_age_wykres <- dane %>%
  select(age, subscribed)%>%
  dplyr::filter(subscribed == "yes")

dane_age_wykres %>% 
  ggplot() + 
  geom_histogram(mapping = aes(x = age, y = ..density..),
                 breaks = seq(18,98,5),
                 fill="#FF6666",
                 colour="black")+
  labs(x =  "Age",
       y = "Density")+
  ggtitle("Wiek klientów, którzy założyli lokatę")+
  scale_x_continuous(breaks = seq(18,98,5))+
  theme_minimal()+
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))



# Wykres dla zmiennej "balance"
dane_balance_wykres <- dane %>%
  select(balance, subscribed)

dane_balance_wykres$group <- NA

for(i in 1:nrow(dane_balance_wykres)){
  if (dane_balance_wykres$balance[i] < 0){
    dane_balance_wykres$group[i] <- " <0tys."
  }
  if (dane_balance_wykres$balance[i] >= 0 && dane_balance_wykres$balance[i] < 5000){
    dane_balance_wykres$group[i] <- " 0-5tys."
  }
  if (dane_balance_wykres$balance[i] >= 5000 && dane_balance_wykres$balance[i] < 10000){
    dane_balance_wykres$group[i] <- " 5tys.-10tys."
  }
  if (dane_balance_wykres$balance[i] >= 10000){
    dane_balance_wykres$group[i] <- "10tys. i więcej "
  }
}

balance_wykres <- dane_balance_wykres %>%
  ggplot(aes(factor(group), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Balance",
       y = "Count",
       fill = "Subscribed")+
  ggtitle("Wyniki kampanii marketingowej w zależności od średniego bilansu na koncie")+
  scale_y_continuous(breaks = seq(0, 10000, 30000))+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))

# boxplot
balance_wykres_boxplot <- ggplot(dane) +
  geom_boxplot(aes(y = balance, fill=subscribed)) + 
  labs(y =  "Balance",
       fill=  "Subscribed")+
  ggtitle("Średni bilans konta klientów którzy założyli lokatę")+
  theme_minimal()+
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))



# Wykres dla zmiennej "duration"
dane_duration_wykres <- dane %>%
  select(duration, subscribed)

dane_duration_wykres$group <- NA

for(i in 1:nrow(dane_duration_wykres)){
  if (dane_duration_wykres$duration[i] >= 0 && dane_duration_wykres$duration[i] < 100){
    dane_duration_wykres$group[i] <- "0-100s"
  }
  if (dane_duration_wykres$duration[i] >= 100 && dane_duration_wykres$duration[i] < 200){
    dane_duration_wykres$group[i] <- "100-200s"
  }
  if (dane_duration_wykres$duration[i] >= 200 && dane_duration_wykres$duration[i] < 300){
    dane_duration_wykres$group[i] <- "200-300s"
  }
  if (dane_duration_wykres$duration[i] >= 300 && dane_duration_wykres$duration[i] < 400){
    dane_duration_wykres$group[i] <- "300-400s"
  }
  if (dane_duration_wykres$duration[i] >= 400){
    dane_duration_wykres$group[i] <- "400s i więcej"
  }
}

duration_wykres <- dane_duration_wykres %>%
  ggplot(aes(factor(group), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Duration",
       y ="Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 10000, 30000))+
  ggtitle("Wyniki kampanii marketingowej w zależności od czasu rozmowy z klientem")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))


# boxplot
duration_wykres_boxplot <- ggplot(dane) +
  geom_boxplot(aes(y = duration, fill=subscribed)) + 
  labs(y =  "Duration",
       fill =  "Subscribed")+
  ggtitle("Czas kontaktu z klientem")+
  theme_minimal()+
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))


# Wykres dla zmiennej "campaign"
dane_campaign_wykres <- dane %>%
  select(campaign, subscribed)

dane_campaign_wykres$group <- NA

for(i in 1:nrow(dane_campaign_wykres)){
  if (dane_campaign_wykres$campaign[i] >= 1 && dane_campaign_wykres$campaign[i] < 2){
    dane_campaign_wykres$group[i] <- "<2"
  }
  if (dane_campaign_wykres$campaign[i] >= 2 && dane_campaign_wykres$campaign[i] < 4){
    dane_campaign_wykres$group[i] <- "2-4"
  }
  if (dane_campaign_wykres$campaign[i] >= 4 && dane_campaign_wykres$campaign[i] < 6){
    dane_campaign_wykres$group[i] <- "4-6"
  }
  if (dane_campaign_wykres$campaign[i] >= 6){
    dane_campaign_wykres$group[i] <- "6 i więcej"
  }
}

campaign_wykres <- dane_campaign_wykres %>%
  ggplot(aes(factor(group), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Campaign",
       y = "Count",
       fill = "Subscribed")+
  scale_y_continuous(breaks = seq(0, 10000, 30000))+
  ggtitle("Wyniki kampanii w zależności od ilości wykonanych telefonów do klienta")+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))


# boxplot
campaign_wykres_boxplot <- ggplot(dane) +
  geom_boxplot(aes(y = campaign, fill=subscribed)) + 
  labs(y =  "Campaign",
       fill =  "Subscribed")+
  ggtitle("Ilość wykonanych telefonów do klienta w trakcie kampanii")+
  theme_minimal()+
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))



# Wykres dla zmiennej "previous"
dane_previous_wykres <- dane %>%
  select(previous, subscribed)

dane_previous_wykres$group <- NA

for(i in 1:nrow(dane_previous_wykres)){
  if (dane_previous_wykres$previous[i] >= 0 && dane_previous_wykres$previous[i] < 2){
    dane_previous_wykres$group[i] <- "<2"
  }
  if (dane_previous_wykres$previous[i] >= 2 && dane_previous_wykres$previous[i] < 4){
    dane_previous_wykres$group[i] <- "2-4"
  }
  if (dane_previous_wykres$previous[i] >= 4 && dane_previous_wykres$previous[i] < 6){
    dane_previous_wykres$group[i] <- "4-6"
  }
  if (dane_previous_wykres$previous[i] >= 6){
    dane_previous_wykres$group[i] <- "6 i więcej"
  }
}

previous_wykres <- dane_previous_wykres %>%
  ggplot(aes(factor(group), fill = factor(subscribed))) +
  geom_bar(position=position_dodge()) + 
  labs(x= "Previous",
       y = "Count",
       fill = "Subscribed")+
  ggtitle("Wyniki kampanii w zależności od ilości telefonów do klienta przed rozpoczęciem kampanii ")+
  scale_y_continuous(breaks = seq(0, 10000, 30000))+
  theme_minimal()+
  theme(legend.position = "right",
        axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.4))

# previous = 275 - Jest to wartość odstająca. Liczba zdecydowanie odbiega od reszty 
# wartości tej cechy. Dodatkowo klient ten nie zalega ze spłatą karty kredytowej, 
# więc duża liczba telefonów wykonana przed kampanią nie znajduje uzasadnienia w danych.
dane <- dane %>%
  filter(previous < 275)

dane.dostosowane <- dane.dostosowane %>%
  dplyr::filter(previous < 275)

# boxplot
previous_wykres_boxplot <- ggplot(dane) +
  geom_boxplot(aes(y = previous, fill=subscribed)) + 
  labs(y =  "Previous",
       fill =  "Subscribed")+
  ggtitle("Ilość wykonanych telefonów przed rozpoczęciem kampanii")+
  theme_minimal()+
  theme(axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18),
        plot.title = element_text(size = 18, face = "bold", hjust = 0.5))


# --------------Współczynnik V-Cramera dla danych jakościowych------------------

# Współczynnik V-Cramera ocenia stopień związku miedzy cechami jakościowymi. 

# Współczynnik V-Cramera dla zmiennej job
table.job <- table(dane$job, dane$subscribed)
cramer.v(table.job)

# Współczynnik V-Cramera dla zmiennej marital
table.marital <- table(dane$marital, dane$subscribed)
cramer.v(table.marital)

# Współczynnik V-Cramera dla zmiennej education
table.education <- table(dane$education, dane$subscribed)
cramer.v(table.education)

# Współczynnik V-Cramera dla zmiennej default
table.default <- table(dane$default, dane$subscribed)
cramer.v(table.default)

# Współczynnik V-Cramera dla zmiennej housing
table.housing <- table(dane$housing, dane$subscribed)
cramer.v(table.housing)

# Współczynnik V-Cramera dla zmiennej loan
table.loan <- table(dane$loan, dane$subscribed)
cramer.v(table.loan)

# Współczynnik V-Cramera dla zmiennej contact
table.contact <- table(dane$contact , dane$subscribed)
cramer.v(table.contact)

# Współczynnik V-Cramera dla zmiennej poutcome
table.poutcome <- table(dane$poutcome, dane$subscribed)
cramer.v(table.poutcome)

# Współczynnik V-Cramera dla zmiennej month
table.month <- table(dane$month, dane$subscribed)
cramer.v(table.month)

# Współczynnik V-Cramera dla zmiennej day(week)
table.week <- table(dane.dostosowane$week, dane.dostosowane$subscribed)
cramer.v(table.week)



# ------------------------------------------------------------------------------
# --------------------------------KLASYFIKACJA----------------------------------
# ------------------------------------------------------------------------------

# PODZIAL ZBIORYU NA TESTOWY I UCZACY
# Podzia zbioru zostanie wykonany raz, aby dla wszytskich wykorzytsanych metod 
# zbiory testowe i uczace byly takie same. Wtedy wyniki tych metoda beda porownywalne

set.seed(123)
index <- sample(31646,25316, replace = F)
zbior.uczacy <- dane.dostosowane[index,]
zbior.testowy <- dane.dostosowane[-index,]

# sprawdzam czy prawdopodbienstwo wystapienia 1 w biorze uczacym jest mniejsze od
# 0.05. Jesli byloby mniejsze to dobrze jest wtedy obnizyc prog odciecia. Ale nie jest 
# bo wynosi 0.12. 
# Prog odsiecia bede jeszcze sprawdzac krzywa ROC
p.1 <- sum(zbior.uczacy$subscribed)/nrow(zbior.uczacy)
p.2 <-sum(zbior.testowy$subscribed)/nrow(zbior.testowy)

# Dodatkowo prawdopodbienstwo wystapenia 1 jest podbne w zbiorze testowym i uczacym.
# Wiec powinno byc ok. 

# ------------------------------------------------------------------------------
# --------------------------------KLASYFIKACJA KNN------------------------------
# ------------------------------------------------------------------------------

# Standaryzacja zmiennych ilosciowych
col_nazwy <- colnames(dane_ciagle)

zbior.uczacy.std <- zbior.uczacy
zbior.uczacy.std[,col_nazwy] <- scale(zbior.uczacy[,col_nazwy])

zbior.testowy.std <- zbior.testowy
zbior.testowy.std[,col_nazwy] <- scale(zbior.testowy[,col_nazwy])

# Klasyfikacja KNN i wybor najlepszego k
# k- ilosc sasiadow brana pod uwage przy klasyfikacji

library(class)
il_k <- seq(1,20,1)
k_czulosc <- as.data.frame(il_k)
k_czulosc$czulosc.uczacy <- NA
k_czulosc$specyficznosc.uczacy <- NA

for(nk in 1:20){
  # ZBIOR UCZACY
  knn.uczacy <- knn(train = zbior.uczacy.std[,-35],
                    test = zbior.uczacy.std[,-35],
                    cl = zbior.uczacy.std[,"subscribed"],
                    k = nk)
  
  # Macierz bledu
  t1 <- table(knn.uczacy, zbior.uczacy.std$subscribed)
  #colnames(t1) <- c("no_subscribed", "subscribed")
  
  # Czulosc na zbiorze uczacym
  sensivity.uczacy <- t1[2,2]/(t1[2,2]+t1[1,2])
  specificity.uczacy <- t1[1,1]/(t1[1,1] + t1[2,1])
  k_czulosc[nk,"czulosc.uczacy"] <- sensivity.uczacy
  k_czulosc[nk, "specyficznosc.uczacy"] <- specificity.uczacy
}

# Czułość w zależności od ilości sąsiadów
library(tidyr)
k_czulosc  <- k_czulosc %>%
  pivot_longer("czulosc.uczacy":"specyficznosc.uczacy",
              names_to = "miara", values_to = "wartosc")

#dev.off()
k_czulosc %>%
  ggplot(aes(x = il_k, y = wartosc, col = miara))+
  geom_point(size = 1.5)+
  geom_line()+
  xlab("k")+
  ylab("Wartość")+
  scale_x_continuous(breaks = seq(1, 20, 1))+
  theme_minimal()+
  theme(legend.position = "top",
    axis.text = element_text(size = 15),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 15),
        legend.title = element_text(size = 18))
# Wybieram k = 3; 

# ZBIOR TESTOWY
knn.testowy <- knn(train = zbior.uczacy.std[,-35],
                   test = zbior.testowy.std[,-35],
                   cl = zbior.uczacy.std[,"subscribed"],
                   k = 3)

# Macierz bledu
t2 <- table(knn.testowy, zbior.testowy.std$subscribed)
colnames(t2) <- c("no_subscribed", "subscribed")

# Czulosc na zbiorze uczacym
sensivity.testowy <- t2[2,2]/(t2[2,2]+t2[1,2])
specificity.testowy <- t2[1,1]/(t2[1,1] + t2[2,1])

# KRZYWA ROC
#library(pROC)
ROC.knn.t <- roc(zbior.testowy.std$subscribed, as.numeric(knn.testowy))
ROC.knn.u <- roc(zbior.uczacy.std$subscribed, as.numeric(knn.uczacy))

plot(ROC.knn.u, col = "red")
plot(ROC.knn.t, add = T)
legend("topleft", legend=c("Zbiór uczący", "Zbiór testowy"),
       col=c("red", "black"), lty=1:2, cex=0.8)

auc(ROC.knn.t)
auc(ROC.knn.u)


# ------------------------------------------------------------------------------
# -----------------------------KLASYFIKATOR NAIWNY BAYESA-----------------------
# ------------------------------------------------------------------------------

# dyskrestyzacja
library(arules)

# Kategorie okreslajace granice interwalow
dane.dostosowane.nb <- dane.dostosowane
dane.dostosowane.nb$age <- discretize(dane.dostosowane$age, method = "frequency", breaks = 5)
dane.dostosowane.nb$balance <- discretize(dane.dostosowane$balance, method = "frequency", breaks = 4)
dane.dostosowane.nb$duration <- discretize(dane.dostosowane$duration, method = "frequency", breaks = 4)
dane.dostosowane.nb$campaign <- discretize(dane.dostosowane$campaign, method = "frequency", breaks = 2)
dane.dostosowane.nb$previous<- discretize(dane.dostosowane$previous, method = "fixed", breaks = c(0,2,4,6,275))

uczacy.nb <- dane.dostosowane.nb[index,]
testowy.nb <- dane.dostosowane.nb[-index,]

library(e1071)
wynik.nb <- naiveBayes(subscribed ~., data = uczacy.nb)
wynik.nb

#Prognoza na zbiorze uczacym + wybor progu odciecia
nb.prog.ucz <- predict(wynik.nb, uczacy.nb, type = "raw")

nb.prog.ucz <- as.data.frame(nb.prog.ucz)
nb.prog.ucz$wynik05 <- NA
nb.prog.ucz$wynik04 <- NA
nb.prog.ucz$wynik03 <- NA
for(i in 1:nrow(nb.prog.ucz)){
  if(nb.prog.ucz[i,"1"] > 0.5){
    nb.prog.ucz[i,"wynik05"] <- 1
  }else{
    nb.prog.ucz[i,"wynik05"] <- 0
  }
  
  if(nb.prog.ucz[i,"1"] > 0.4){
    nb.prog.ucz[i,"wynik04"] <- 1
  }else{
    nb.prog.ucz[i,"wynik04"] <- 0
  }
  
  if(nb.prog.ucz[i,"1"] > 0.3){
    nb.prog.ucz[i,"wynik03"] <- 1
  }else{
    nb.prog.ucz[i,"wynik03"] <- 0
  }
}


# KRZYWA ROC
#library(pROC)
par(mfrow = c(1,3))
ROC.nb.05.u <- roc(uczacy.nb$subscribed, predictor = nb.prog.ucz$wynik05, plot = TRUE, print.auc = TRUE, col = 'red')
ROC.nb.04.u <- roc(uczacy.nb$subscribed, as.numeric(nb.prog.ucz$wynik04), plot = TRUE, print.auc = TRUE, col = 'blue')
ROC.nb.03.u <- roc(uczacy.nb$subscribed, as.numeric(nb.prog.ucz$wynik03), plot = TRUE, print.auc = TRUE, col = 'black')
par(mfrow = c(1,1))

#Macierz bledu
t1.nb.03 <- table(nb.prog.ucz$wynik03, uczacy.nb$subscribed)
t1.nb.04 <- table(nb.prog.ucz$wynik04, uczacy.nb$subscribed)
t1.nb.05 <- table(nb.prog.ucz$wynik05, uczacy.nb$subscribed)

#Czulosc
czulosc.nb.ucz.03 <- t1.nb.03[2,2]/(t1.nb.03[2,2]+t1.nb.03[1,2])
czulosc.nb.ucz.04 <- t1.nb.04[2,2]/(t1.nb.04[2,2]+t1.nb.04[1,2])
czulosc.nb.ucz.05 <- t1.nb.05[2,2]/(t1.nb.05[2,2]+t1.nb.05[1,2])

specyficznosc.nb.ucz.03 <- t1.nb.03[1,1]/(t1.nb.03[1,1] + t1.nb.03[2,1])

# ------------------------------------------------------------------------------
# Prognoza na zbiorze testowym
nb.prog.test <- predict(wynik.nb, testowy.nb, type = "raw")

nb.prog.test <- as.data.frame(nb.prog.test)
nb.prog.test$wynik < -NA
for(i in 1:nrow(nb.prog.test)){
  if(nb.prog.test[i,"1"] > 0.3){
    nb.prog.test[i,"wynik"] <- 1
  }else{
    nb.prog.test[i,"wynik"] <- 0
  }
}

# Macierz bledu
t2.nb <- table(nb.prog.test$wynik, testowy.nb$subscribed)

#Czulosc na zbiorze testowym
czulosc.nb.t <- t2.nb[2,2]/(t2.nb[2,2]+t2.nb[1,2])
specyficznosc.nb.t <- t2.nb[1,1]/(t2.nb[1,1]+t2.nb[2,1])

# ROC
roc(uczacy.nb$subscribed, as.numeric(nb.prog.ucz$wynik03), plot = TRUE, print.auc = TRUE, col = 'red')
roc(testowy.nb$subscribed, predictor = nb.prog.test$wynik, plot = TRUE, print.auc = TRUE, col = 'black', add = T, print.auc.y = 0.45)
legend("topleft", legend=c("Zbiór uczący", "Zbiór testowy"),
       col=c("red", "black"), lty=1:2, cex=0.8)


